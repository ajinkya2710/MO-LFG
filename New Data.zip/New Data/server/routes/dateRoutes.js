import { Router } from 'express';
import { dateCheck, downloadFile } from '../controllers/dateCheckController.js';

const router = Router();

// Handle POST request for date check
router.post('/check-date', dateCheck)

// Handle GET request to download a file
router.get('/check-date', downloadFile);

export default router;
