import { existsSync, access, constants } from 'fs';
import path from 'path';

const filePath = 'E:/files/file_example_XLS_1000.xls'

export function dateCheck (req, res) {
    const { year, month } = req.body;

    if (!year || !month) {
        return res.status(404).json({ success: 0, message: "Please select the month and year" });
    }
    if (!filePath) {
        return res.status(404).json({
            success: 0,
            message: `File path not received`
        })
    } else if (!existsSync(filePath)) {
        return res.status(404).json({
            success: 0,
            message: `File not found\nPath: ${filePath}`
        });
    }

    setTimeout(() => {
        res.json({
            success: 1,
            message: `File Generated Successfully\nPath:${filePath}`
        });
    }, 1000);
}

export function downloadFile (req, res) {

    access(filePath, constants.F_OK, (err) => {
        if (err) {
            return res.status(404).json({
                success: 0,
                message: `File not found\nPath: ${filePath}`
            });
        }

        res.download(filePath, (downloadErr) => {
            if (downloadErr) {
                return res.status(500).json({
                    success: 0,
                    message: "Error downloading file"
                });
            }
        });
    });

}
