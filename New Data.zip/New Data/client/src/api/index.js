const checkDate = async (year, month) => {
    try {
        const response = await fetch('http://localhost:5000/api/check-date', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ year, month }),
        });

        const result = await response.json();
        // const filename = result.filename; // Get the dynamic filename from the response
        if (result.success === 1) { // Assuming a success flag is returned in the response
            try {
                const downloadResponse = await fetch('http://localhost:5000/api/check-date', {
                    method: 'GET',
                });

                if (downloadResponse.ok) {
                    const blob = await downloadResponse.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    // a.download = 'tests-sample.xls';
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                } else {
                    console.error('Failed to download file');
                }
            } catch (error) {
                console.error('Error during file download:', error);
            }
        } else {
            console.error('Date check failed:', result.message);
        }

        return result;

    } catch (error) {
        return { success: 0, message: "Error" };
    }
};

module.exports = { checkDate };
