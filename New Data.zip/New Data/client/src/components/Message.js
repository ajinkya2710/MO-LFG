import React from 'react';
import '../styles/App.css';

const Message = ({ message }) => {
    return (
        <div className={`message ${message.success ? 'success' : 'error'}`}>
            {message.message.split('\n').map((str, index) => (
                <p key={index}>{str}</p>
            ))}
        </div>
    );
};

export default Message;
